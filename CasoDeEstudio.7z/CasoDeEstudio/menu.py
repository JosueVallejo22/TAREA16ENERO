import os
class Menu:
    def __init__(self):
        pass

    def menu(self, Usuario, Rol, Opciones):
        print("-"*43)
        print("Usuario: {}      ID: {}\n".format(Usuario.NomUser, Usuario.CeduUser))
        print("Tipo: {}".format(Rol.TipoRol))
        print("")
        for i in Opciones.ListOpercSys:
            print("{}.   {}".format(i.CodOpercSys, i.DescrpOpercSys))
        print("-"*43)
    
    def cls(self):
        os.system("cls")


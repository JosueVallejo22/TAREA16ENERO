class Rol():
    contCod = 2
    ListRol= [{"codigo" : 1, "Descripcion" : "Estudiante"}, {"codigo" : 2, "Descripcion" : "Docente"}]
    def __init__(self, nombre):
          Rol.contCod += 1
          self.CodRol = Rol.contCod
          self.TipoRol = nombre


    def mostrarNomRol(self):
        print("Usuario: {} {}".format(self.CodRol, self.NomRol))

    def  registroRol(self):
        return {"codigo" : self.CodRol, "Descripcion" : self.TipoRol}
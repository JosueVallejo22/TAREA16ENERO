from re import I
from Usuario import Usuario
from Rol import Rol
from OpcionesSys import OpcionesSistema
from OperacionesSys import OperacionesSistema
from menu import Menu 

Rol1 = Rol("Estudiante")
opc1 = OpcionesSistema(1, "Mis Materias", 1)
oper1_1 = OperacionesSistema("Ver materias", 1)
oper1_2 = OperacionesSistema("Ver profesores")
oper1_3 = OperacionesSistema("Ver Compañeros")
opc1.GuadarOpercSys(oper1_1)
opc1.GuadarOpercSys(oper1_2)
opc1.GuadarOpercSys(oper1_3)

Rol2 = Rol("Docente")
opc2 = OpcionesSistema(1, "Mis Estudiantes")
oper2_1 = OperacionesSistema("Ver por Curso")
oper2_2 = OperacionesSistema("Ver Ver Foro por preguntas")
opc2.GuadarOpercSys(oper2_1)
opc2.GuadarOpercSys(oper2_2)


user1 = Usuario('0941213548','Josué Zambrano','vinilo','jzambranoc9@unemi.edu.ec','0963999834',1)
user2 = Usuario('0941213548','Daniel Vera','traste','dverac@unemi.edu.ec','0945923847',2)


ListaUsuarios = {Rol1.CodRol : user1, Rol2.CodRol : user2}



print("[   Número   ]", " "*3, "[   Nombre   ]", " "*4, "[  Rol  ]", " "*6, "[     Correo     ]", " "*6, "[   Telf   ]")
cont=0

for i in ListaUsuarios:
    cont+=1
    cod = cont
    nom = ListaUsuarios[i].NomUser
    rol = i
    correo = ListaUsuarios[i].CorreoUser
    telf = ListaUsuarios[i].TelfUser

    print(" "*5,cod," "*(11-len(str(cod))),nom," "*(22-len(nom)),rol," "*(10-len(str(rol))),correo, " "*(26-len(correo)), telf)

#input("Presione ENTER para continuar...")

menupr = Menu()
menupr.cls()
menupr.menu(user1,Rol1,opc1)



      
class Usuario():
    ListaUsuarios= [{"Cedula":"0914192182","nombre":"Josué Zambrano","Clave":"vinilo","Correo":"jza@unemi.edu.ec","Teléfono":"0963999834","CodigoRol":1},
                {"Cedula":"0941213548","nombre":"Daniel Vera","Clave":"traste","Correo":"dverac@unemi.edu.ec","Teléfono":"0945923847","CodigoRol":2}]
                
    def __init__(self, ced, nom, clav, correo, telf, rol):
          self.CeduUser = ced
          self.NomUser = nom
          self.ClaveUser = clav
          self.CorreoUser = correo
          self.TelfUser = telf
          self.codRol = rol

    def mostrarNomUser(self):
        print("Usuario: {} {}".format(self.CeduUser, self.NomUser))

    def  registroUser(self):
        return {"Cedula":self.CeduUser,"nombre":self.NomUser,"Clave":self.ClaveUser,
                "Correo":self.CorreoUser,"Teléfono":self.TelfUser,"CodigoRol":self.codRol}       
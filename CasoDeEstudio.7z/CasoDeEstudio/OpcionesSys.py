class OpcionesSistema():
    ListaOpciones = []
    def __init__(self, codigo, nombre, rol):
          self.CodOpcSys = codigo
          self.NomOpcSys = nombre
          self.RolOpcSys = rol
          self.ListOpercSys = []

    def GuadarOpercSys(self, dato):
        self.ListOpercSys.append(dato)